export type Bit = 0 | 1;

export type BitSequence = Bit[]; 