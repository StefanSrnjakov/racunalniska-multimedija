## PREPARED TESTS: 

./dn1 ./test-files/test.bmp fr 000000000000000011111111 111111110000000000000000
./dn1 ./test-files/test.bin fr 0100 0110 

Search for generated files in: /out-files dir
